Please download these bins to the specified address.

Bin                           Address
boot_v1.1.bin---------------->0x00000
user1.bin-------------------->0x01000
esp_init_data_default.bin---->0x7C000
blank.bin-------------------->0x7E000